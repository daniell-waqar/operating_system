#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

struct thread_data {
    int h;
    int w;
};

void *areaRec(void * arg) {
   
    printf("Thread : Process Id is %d and Thread Id is %ld\n" , getpid(), pthread_self());
    struct thread_data *Area;
    Area = (struct thread_data *) arg;
    int area = Area->h *  Area->w;
    printf("Area calculated done!\n");

    printf("Area =  %d\n", area);
    pthread_exit(NULL);
    
}


void * perimiterRec(void * arg) {
    printf("Thread : Process Id is %d and Thread Id is %ld\n" , getpid(), pthread_self());
    struct thread_data *Perimiter;
    Perimiter = (struct thread_data *) arg;
    int perimiter = 2*Perimiter->h + 2*Perimiter->w;
    printf("Perimiter calculated done!\n");
    printf("Perimiter =  %d\n", perimiter);
    pthread_exit(NULL);

}


int main() {
    struct thread_data Area;
    struct thread_data Perimiter;

    int height, width;

    printf("Enter the height of Rectangle--");
    scanf("%d" , &height);

    printf("Enter the width of Rectangle--");
    scanf("%d" , &width);

    Area.h = height;
    Area.w = width;

    Perimiter.h = height;
    Perimiter.w = width;

   

    pthread_t tid1, tid2;

    pthread_create(&tid1, NULL, areaRec, (void *) &Area);
  

    pthread_create(&tid2, NULL, perimiterRec, (void *) &Perimiter);
  

    pthread_join(tid1, NULL);

    pthread_join(tid2, NULL);



    return 0;
}