#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

struct thread_data
{
    int a, b,c;
};

struct thread_data somedata;

void *sumElements(void *threadArg)
{
    struct thread_data *my_data;
    my_data = (struct thread_data * ) threadArg;
   
  
    somedata.c = somedata.a + somedata.b;
    printf("Element of Array1 is: %d,\nElement of Array2 is: %d,\nSum of Both Element: %d\n", my_data->a, my_data->b, my_data->c);
    pthread_exit(NULL);


}


int main(){

  
    int size;

    printf("Enter size of Array: ");
    scanf("%d" , &size);

    int arr1[size];
    int arr2[size];

    int thrd_return;

    pthread_t threads[size];


    for(int i =0 ; i < size; i++)
    {   
        printf("Enter element of  Array1 : ");
        scanf("%d" , &arr1[i]);

        somedata.a = arr1[i];


        printf("Enter element of  Array2 : ");
        scanf("%d" , &arr2[i]);

        somedata.b = arr2[i];
    

    
        printf("Creating thread that will add parallel elements!\n");
        thrd_return = pthread_create(&threads[i], NULL, sumElements,(void *) &somedata);
       
        if(thrd_return){ // other than 0 return value
            printf("ERROR; return code from pthread_create() is %d\n", thrd_return);
            exit(-1);
        }

        pthread_join(threads[i], NULL );

        
    }
     printf("Addition of all parallel elements done!\n");

     printf("Exiting main.\n");

   
 
   
    return 0;
}